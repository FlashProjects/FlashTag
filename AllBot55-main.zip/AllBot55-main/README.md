# Mention All Bot 👥
_**Bu bot, gruplarda 10.000'e kadar üyeden bahsedebilir ve kanallarda 200'e kadar üyelerden bahsedebilir!**_

### 🏷 Bilgimasyon
- Language: Python.
- Telegram Library: Telethon.

### 🚀 Heroku'ya dağıtın
[![Deploy](https://www.herokucdn.com/deploy/button.svg)](https://heroku.com/deploy?template=https://github.com/Mehmetbaba06/AllBot55)

### 🎯 Krediler ve Diğer
- [Beni](https://github.com/Mehmetbaba06) for this Project ;)

**Github'da beni takip etmeyi unutma.✌️**
